export interface GoogleSearchResult {
  title: string;
  link: string;
  snippet: string;
  displayLink: string;
}

export interface GoogleSearchResponse {
  items?: GoogleSearchResult[];
  searchInformation?: {
    totalResults: string;
    searchTime: number;
  };
}

export interface RankingResult {
  keyword: string;
  position: number;
  url: string;
  title: string;
  domain: string;
  change?: number;
}

export class SearchAPI {
  private apiKey: string;
  private searchEngineId: string;

  constructor(apiKey: string, searchEngineId: string) {
    this.apiKey = apiKey;
    this.searchEngineId = searchEngineId;
  }

  async searchKeyword(
    keyword: string,
    targetDomain: string,
    maxResults: number = 100,
  ): Promise<RankingResult[]> {
    const results: RankingResult[] = [];
    const resultsPerPage = 10;
    const maxPages = Math.ceil(maxResults / resultsPerPage);

    try {
      for (let page = 0; page < maxPages; page++) {
        const start = page * resultsPerPage + 1;
        const searchUrl = this.buildSearchUrl(keyword, start);

        const response = await fetch(searchUrl);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data: GoogleSearchResponse = await response.json();

        if (data.items) {
          data.items.forEach((item, index) => {
            const position = start + index;
            const domain = this.extractDomain(item.link);

            if (domain.includes(targetDomain.toLowerCase())) {
              results.push({
                keyword,
                position,
                url: item.link,
                title: item.title,
                domain: domain,
              });
            }
          });
        }

        // If we have enough results or no more items, break
        if (!data.items || data.items.length < resultsPerPage) {
          break;
        }
      }

      return results.sort((a, b) => a.position - b.position);
    } catch (error) {
      console.error("Search API error:", error);
      throw new Error("Không thể kết nối đến Google Search API");
    }
  }

  private buildSearchUrl(keyword: string, start: number = 1): string {
    const params = new URLSearchParams({
      key: this.apiKey,
      cx: this.searchEngineId,
      q: keyword,
      start: start.toString(),
      num: "10",
    });

    return `https://www.googleapis.com/customsearch/v1?${params.toString()}`;
  }

  private extractDomain(url: string): string {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname.toLowerCase().replace("www.", "");
    } catch {
      return url.toLowerCase();
    }
  }

  static validateApiCredentials(
    apiKey: string,
    searchEngineId: string,
  ): boolean {
    return Boolean(
      apiKey &&
        apiKey.trim().length > 0 &&
        searchEngineId &&
        searchEngineId.trim().length > 0,
    );
  }
}

// Demo function for testing without API keys
export async function searchKeywordDemo(
  keyword: string,
  targetDomain: string,
): Promise<RankingResult[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1500));

  // Generate some realistic demo results
  const demoResults: RankingResult[] = [];
  const positions = [3, 7, 15, 23, 31, 45];

  positions.forEach((position, index) => {
    if (index < 3) {
      // Only show first 3 results for demo
      demoResults.push({
        keyword,
        position,
        url: `https://${targetDomain}/${index === 0 ? "seo-guide" : index === 1 ? "blog/seo-tips" : "tools/keyword-planner"}`,
        title: `${keyword} ${index === 0 ? "- Complete Guide" : index === 1 ? "- Expert Tips" : "- Free Tools"} | ${targetDomain}`,
        domain: targetDomain,
        change: index === 0 ? 2 : index === 1 ? -1 : undefined,
      });
    }
  });

  return demoResults;
}
