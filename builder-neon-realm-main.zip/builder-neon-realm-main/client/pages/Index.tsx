import React, { useState } from "react";
import {
  Search,
  Target,
  TrendingUp,
  Globe,
  BarChart3,
  Settings,
  CheckCircle,
  AlertCircle,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { SearchAPI, searchKeywordDemo, RankingResult } from "@/lib/search-api";
import ApiConfig from "@/components/api-config";

export default function Index() {
  const [keyword, setKeyword] = useState("");
  const [targetDomain, setTargetDomain] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<RankingResult[]>([]);
  const [searchProgress, setSearchProgress] = useState(0);
  const [searchAPI, setSearchAPI] = useState<SearchAPI | null>(null);
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleApiConfig = (apiKey: string, searchEngineId: string) => {
    if (apiKey && searchEngineId) {
      setSearchAPI(new SearchAPI(apiKey, searchEngineId));
      setIsDemoMode(false);
    } else {
      setSearchAPI(null);
      setIsDemoMode(true);
    }
  };

  const handleSearch = async () => {
    if (!keyword.trim() || !targetDomain.trim()) return;

    setIsSearching(true);
    setSearchProgress(0);
    setResults([]);
    setError(null);

    // Simulate search progress
    const progressInterval = setInterval(() => {
      setSearchProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + Math.random() * 20;
      });
    }, 200);

    try {
      let searchResults: RankingResult[];

      if (searchAPI && !isDemoMode) {
        // Use real Google Custom Search API
        searchResults = await searchAPI.searchKeyword(keyword, targetDomain);
      } else {
        // Use demo mode
        searchResults = await searchKeywordDemo(keyword, targetDomain);
      }

      setSearchProgress(100);
      setResults(searchResults);
    } catch (error) {
      console.error("Search failed:", error);
      setError(
        error instanceof Error ? error.message : "Có lỗi xảy ra khi tìm kiếm",
      );
    } finally {
      clearInterval(progressInterval);
      setIsSearching(false);
      setTimeout(() => setSearchProgress(0), 1000);
    }
  };

  const getRankBadgeColor = (position: number) => {
    if (position <= 3) return "bg-success text-success-foreground";
    if (position <= 10) return "bg-warning text-warning-foreground";
    return "bg-destructive text-destructive-foreground";
  };

  const getChangeIcon = (change?: number) => {
    if (!change) return null;
    if (change > 0) return <TrendingUp className="h-3 w-3 text-success" />;
    return <TrendingUp className="h-3 w-3 text-destructive rotate-180" />;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary">
                <Target className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  RankTracker Pro
                </h1>
                <p className="text-sm text-muted-foreground">
                  Công cụ kiểm tra thứ hạng từ khóa chuyên nghiệp
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isDemoMode && (
                <Badge variant="outline" className="text-xs">
                  Demo Mode
                </Badge>
              )}
              <ApiConfig onConfigChange={handleApiConfig}>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-2" />
                  API Settings
                  {!isDemoMode && (
                    <div className="w-2 h-2 bg-success rounded-full ml-2" />
                  )}
                </Button>
              </ApiConfig>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold text-foreground">
              Kiểm Tra Thứ Hạng Từ Khóa
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Theo dõi vị trí của website bạn trên Google với công cụ kiểm tra
              thứ hạng từ khóa miễn phí và chính xác nhất
            </p>
          </div>

          {/* Search Form */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Kiểm Tra Thứ Hạng
              </CardTitle>
              <CardDescription>
                Nhập từ khóa và tên miền để kiểm tra vị trí hiện tại trên Google
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Từ khóa</label>
                  <Input
                    placeholder="VD: SEO marketing"
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Tên miền</label>
                  <Input
                    placeholder="VD: example.com"
                    value={targetDomain}
                    onChange={(e) => setTargetDomain(e.target.value)}
                    className="bg-background"
                  />
                </div>
              </div>

              {isSearching && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">
                      {isDemoMode
                        ? "Đang tìm kiếm (Demo)..."
                        : "Đang tìm kiếm..."}
                    </span>
                    <span className="text-muted-foreground">
                      {Math.round(searchProgress)}%
                    </span>
                  </div>
                  <Progress value={searchProgress} className="h-2" />
                </div>
              )}

              {error && (
                <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/10">
                  <div className="flex items-center gap-2 text-destructive">
                    <AlertCircle className="h-4 w-4" />
                    <span className="font-medium">Lỗi</span>
                  </div>
                  <p className="text-sm text-destructive mt-1">{error}</p>
                </div>
              )}

              {isDemoMode && (
                <div className="p-4 rounded-lg border border-info/20 bg-info/10">
                  <div className="flex items-center gap-2 text-info">
                    <AlertCircle className="h-4 w-4" />
                    <span className="font-medium">Chế độ Demo</span>
                  </div>
                  <p className="text-sm text-info mt-1">
                    Hiện tại đang sử dụng dữ liệu mẫu. Để có kết quả thực tế,
                    vui lòng cấu hình Google Custom Search API.
                  </p>
                </div>
              )}

              <Button
                onClick={handleSearch}
                disabled={
                  !keyword.trim() || !targetDomain.trim() || isSearching
                }
                className="w-full"
                size="lg"
              >
                <Search className="h-4 w-4 mr-2" />
                {isSearching ? "Đang tìm kiếm..." : "Kiểm Tra Thứ Hạng"}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          {results.length > 0 && (
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Kết Quả Tìm Kiếm
                </CardTitle>
                <CardDescription>
                  Tìm thấy {results.length} kết quả cho từ khóa "{keyword}"
                  {isDemoMode && " (Demo)"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {results.map((result, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 rounded-lg border border-border bg-muted/20"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <Badge
                          className={cn(
                            "text-sm font-semibold",
                            getRankBadgeColor(result.position),
                          )}
                        >
                          #{result.position}
                        </Badge>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-foreground truncate">
                            {result.title}
                          </h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Globe className="h-3 w-3 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground truncate">
                              {result.url}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getChangeIcon(result.change)}
                        {result.change && (
                          <span
                            className={cn(
                              "text-sm font-medium",
                              result.change > 0
                                ? "text-success"
                                : "text-destructive",
                            )}
                          >
                            {result.change > 0 ? "+" : ""}
                            {result.change}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-border">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-3">
                  <CheckCircle className="h-8 w-8 text-success" />
                  <h3 className="font-semibold text-foreground">
                    Kết Quả Chính Xác
                  </h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Sử dụng Google Custom Search API để đảm bảo kết quả chính xác
                  và cập nhật
                </p>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-3">
                  <TrendingUp className="h-8 w-8 text-info" />
                  <h3 className="font-semibold text-foreground">
                    Theo Dõi Thay Đổi
                  </h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Theo dõi sự thay đổi thứ hạng theo thời gian để tối ưu hóa SEO
                </p>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-3">
                  <Globe className="h-8 w-8 text-warning" />
                  <h3 className="font-semibold text-foreground">
                    Miễn Phí Sử Dụng
                  </h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Công cụ hoàn toàn miễn phí, không cần đăng ký tài khoản
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Instructions Section */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ExternalLink className="h-5 w-5" />
                Hướng Dẫn Sử Dụng
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-foreground mb-2">
                    Cài Đặt Google Custom Search API
                  </h4>
                  <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>
                      Truy cập{" "}
                      <a
                        href="https://console.cloud.google.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        Google Cloud Console
                      </a>
                    </li>
                    <li>Tạo project mới hoặc chọn project hiện có</li>
                    <li>Bật Custom Search JSON API trong Library</li>
                    <li>Tạo API key trong Credentials</li>
                  </ol>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-2">
                    Cài Đặt Programmable Search Engine
                  </h4>
                  <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>
                      Truy cập{" "}
                      <a
                        href="https://programmablesearchengine.google.com/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        Programmable Search Engine
                      </a>
                    </li>
                    <li>Tạo search engine mới</li>
                    <li>Cấu hình để tìm kiếm toàn bộ web</li>
                    <li>Copy Search Engine ID</li>
                  </ol>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>
              © 2024 RankTracker Pro. Công cụ kiểm tra thứ hạng từ khóa miễn
              phí.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
