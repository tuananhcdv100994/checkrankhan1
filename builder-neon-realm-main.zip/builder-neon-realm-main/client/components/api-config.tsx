import React, { useState, useEffect } from "react";
import { Settings, Eye, EyeOff, ExternalLink, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { SearchAPI } from "@/lib/search-api";

interface ApiConfigProps {
  onConfigChange: (apiKey: string, searchEngineId: string) => void;
  children?: React.ReactNode;
}

export default function ApiConfig({
  onConfigChange,
  children,
}: ApiConfigProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [searchEngineId, setSearchEngineId] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const [isConfigured, setIsConfigured] = useState(false);

  useEffect(() => {
    // Load saved configuration from localStorage
    const savedApiKey = localStorage.getItem("google_api_key");
    const savedSearchEngineId = localStorage.getItem("google_search_engine_id");

    if (savedApiKey && savedSearchEngineId) {
      setApiKey(savedApiKey);
      setSearchEngineId(savedSearchEngineId);
      setIsConfigured(true);
      onConfigChange(savedApiKey, savedSearchEngineId);
    }
  }, [onConfigChange]);

  const handleSave = () => {
    if (SearchAPI.validateApiCredentials(apiKey, searchEngineId)) {
      localStorage.setItem("google_api_key", apiKey);
      localStorage.setItem("google_search_engine_id", searchEngineId);
      setIsConfigured(true);
      onConfigChange(apiKey, searchEngineId);
      setIsOpen(false);
    }
  };

  const handleClear = () => {
    localStorage.removeItem("google_api_key");
    localStorage.removeItem("google_search_engine_id");
    setApiKey("");
    setSearchEngineId("");
    setIsConfigured(false);
    onConfigChange("", "");
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            API Settings
            {isConfigured && (
              <div className="w-2 h-2 bg-success rounded-full ml-2" />
            )}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Cấu Hình Google Custom Search API</DialogTitle>
          <DialogDescription>
            Để sử dụng công cụ kiểm tra thứ hạng, bạn cần cấu hình Google Custom
            Search API
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Hướng dẫn thiết lập</AlertTitle>
            <AlertDescription className="mt-2 space-y-2">
              <p>
                1. Truy cập{" "}
                <a
                  href="https://console.cloud.google.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center"
                >
                  Google Cloud Console <ExternalLink className="h-3 w-3 ml-1" />
                </a>
              </p>
              <p>2. Tạo project mới hoặc chọn project hiện có</p>
              <p>3. Bật Custom Search JSON API trong Library</p>
              <p>4. Tạo API key trong Credentials</p>
              <p>
                5. Truy cập{" "}
                <a
                  href="https://programmablesearchengine.google.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center"
                >
                  Programmable Search Engine{" "}
                  <ExternalLink className="h-3 w-3 ml-1" />
                </a>
              </p>
              <p>6. Tạo search engine mới và copy Search Engine ID</p>
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="api-key">Google API Key</Label>
              <div className="relative">
                <Input
                  id="api-key"
                  type={showApiKey ? "text" : "password"}
                  placeholder="AIzaSy..."
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowApiKey(!showApiKey)}
                >
                  {showApiKey ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="search-engine-id">Search Engine ID</Label>
              <Input
                id="search-engine-id"
                placeholder="a1b2c3d4e5f6g7h8i"
                value={searchEngineId}
                onChange={(e) => setSearchEngineId(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handleClear}
              disabled={!isConfigured}
            >
              Xóa Cấu Hình
            </Button>
            <div className="space-x-2">
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Hủy
              </Button>
              <Button
                onClick={handleSave}
                disabled={
                  !SearchAPI.validateApiCredentials(apiKey, searchEngineId)
                }
              >
                Lưu Cấu Hình
              </Button>
            </div>
          </div>

          {!isConfigured && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Hiện tại đang sử dụng chế độ demo. Để có kết quả thực tế, vui
                lòng cấu hình API.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
